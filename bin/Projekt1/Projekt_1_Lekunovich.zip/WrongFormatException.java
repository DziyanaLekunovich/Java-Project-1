package Projekt1;

public class WrongFormatException extends Exception{

}
