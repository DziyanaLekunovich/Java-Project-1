package Projekt1;

public interface Interface {
	public void changeSalary(Worker w, double s);
	public void dismiss(Worker w);
}
